# Claude 自動化總覽

本目錄包含 Claude 的自動化機制：Commands（明確呼叫）和 Skills（自動觸發）。

---

## Skills（自動觸發）

Skills 位於 `.claude/skills/`，Claude 會**根據請求內容自動判斷**是否套用。

| Skill | 說明 | 自動觸發時機 |
|-------|------|--------------|
| `doc-sync` | 文件同步規則 | 修改 GUIDELINES、SOP、Commands 時 |
| `image-management` | 圖片管理規則 | 處理圖片、新增圖片時 |
| `sop-consistency` | SOP 一致性檢查 | 執行結構變更、目錄重構時 |

> 💡 **Skills vs Commands**：Skills 自動觸發，Commands 需明確輸入 `/command`

---

## Commands（明確呼叫）

以下指令需要明確輸入 `/command` 來執行。

## 指令清單

### 文件維護

| 指令 | 說明 | 觸發時機 |
| ---- | ---- | -------- |
| `/update_doc` | 更新 .agent 文件結構 | 專案架構變更後 |
| `/check_sop` | SOP 一致性檢查 | 每月 / 結構變更後 |

### 定期檢查

| 指令 | 說明 | 觸發時機 |
| ---- | ---- | -------- |
| `/daily_check` | 每日檢查（圖片描述檔、MD/YML 配對） | 每日 |
| `/seo_audit` | SEO 稽核（Title/Description/FAQ） | 每週 |

### 內容生成

| 指令 | 說明 | 觸發時機 |
| ---- | ---- | -------- |
| `/gen_image_meta` | 為新增圖片生成描述檔 | 新增圖片後 |
| `/new_page` | 建立新頁面（index.md + index.yml + assets/） | 新增頁面時 |

### 專案評估

| 指令 | 說明 | 觸發時機 |
| ---- | ---- | -------- |
| `/eval_architecture` | 評估新專案是否適合此架構 | 新專案評估階段 |

---

## 建議工作流程

```
┌─────────────────────────────────────────────────────┐
│                    日常維護週期                      │
├─────────────────────────────────────────────────────┤
│  每日    →  /daily_check                            │
│  每週    →  /seo_audit                              │
│  每月    →  /check_sop                              │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                    新增內容流程                      │
├─────────────────────────────────────────────────────┤
│  1. /new_page        → 建立頁面結構                 │
│  2. 編輯 index.md    → 補充內容                     │
│  3. 上傳圖片         → 放入 assets/                 │
│  4. /gen_image_meta  → 生成圖片描述檔               │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                    結構變更流程                      │
├─────────────────────────────────────────────────────┤
│  1. 執行結構變更                                    │
│  2. /check_sop       → 檢查 SOP 是否需要更新        │
│  3. /update_doc      → 更新文件系統                 │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│                    新專案評估                        │
├─────────────────────────────────────────────────────┤
│  /eval_architecture  → 評估是否適合此架構           │
└─────────────────────────────────────────────────────┘
```

---

## 對應 SOP

| 指令 | 對應 SOP |
| ---- | -------- |
| `/update_doc` | - |
| `/check_sop` | `05_agent_refactor.md` |
| `/daily_check` | `05_agent_refactor.md` |
| `/seo_audit` | `05_agent_refactor.md` |
| `/gen_image_meta` | `02b_image_metadata.md` |
| `/new_page` | `04_seo_structure.md` + `02b_image_metadata.md` |
| `/eval_architecture` | `guide_architecture_evaluation.md` |

---

## 新增 Command

如需新增 Command：

1. 在 `.claude/commands/` 建立 `command_name.md`
2. 定義角色、流程、輸出格式
3. 更新本 README
4. 更新 `.agent/System/changelog.md`

### Command 模板

```markdown
你是一位專業的 [角色]，負責 [職責]。

# [流程名稱]

## Step 1：[步驟名稱]
[步驟說明]

## Step 2：[步驟名稱]
[步驟說明]

## Step N：輸出報告
[報告格式]

## 參考資料
- [相關 SOP 連結]
```

---

## 新增 Skill

如需新增 Skill：

1. 在 `.claude/skills/` 建立 `skill-name/SKILL.md`
2. 定義 YAML frontmatter（name, description）
3. 撰寫 Markdown 指令
4. 更新本 README
5. 更新 `.agent/System/changelog.md`

### Skill 模板

```markdown
---
name: skill-name
description: 簡述功能與觸發時機。當 [情境] 時自動觸發。
---

# Skill 標題

## 規則說明
[詳細規則]

## 執行步驟
1. [步驟 1]
2. [步驟 2]
```

詳見：[Claude Skills 官方文檔](https://code.claude.com/docs/en/skills)

